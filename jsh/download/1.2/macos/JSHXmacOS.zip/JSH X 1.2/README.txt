Thanks for installing JSH X 1.2 for MacOS!

This installation of JSH is a bit different from our standard installation so here's a bit of a walkthrough.

1. Open "jsh". If you see a warning that the file may be malware, don't be afraid, we don't pay Apple $199 a year for us to be a "verified developer", so you have to go into your Settings > Security & Privacy and press "Open Anyway".

2. Once you open the file, you will have 2 windows open instantly. One with the JSH Interface and a terminal window. You are able to close the terminal window if you want to, but it may be important if you accidentally close the popup window with JSH, forget the port the session was on, and want to alleviate the session, as you can press CTRL + C.

3. Enter alleviate once you want to end the session to have more free ports.

You should know how to use JSH X now. Hope you enjoy this new addition into the JSH umbrella.